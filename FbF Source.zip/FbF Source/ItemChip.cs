﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemChip : Chip
{
    public virtual void ActivateChip(Player p)
    {

    }
}
