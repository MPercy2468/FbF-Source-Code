﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class RoomData
{
    //Reference for room prefab data 
    public Room roomPrefab;
    public bool isBossRoom;
}
