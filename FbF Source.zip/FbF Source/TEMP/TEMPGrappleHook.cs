﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TEMPGrappleHook : MonoBehaviour
{
    public LineRenderer lineRenderer;
    public EdgeCollider2D edgeCol;
    // Update is called once per frame
    void Update()
    {
        GenerateRendererCollider();
    }
    void GenerateRendererCollider()
    {
        Vector3[] Vec3positions = new Vector3[lineRenderer.positionCount];
        lineRenderer.GetPositions(Vec3positions);
        Vector2[] positions = new Vector2[Vec3positions.Length];
        for(int i = 0; i < positions.Length; i++)
        {
            positions[i] = new Vector2(Vec3positions[i].x, Vec3positions[i].y);
        }
        edgeCol.points = positions;
    }
}
